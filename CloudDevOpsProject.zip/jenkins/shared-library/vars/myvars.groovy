def greeting() { echo "shared library loaded" }
return this

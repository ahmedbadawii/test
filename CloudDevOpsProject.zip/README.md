# CloudDevOpsProject

مشروع تخرج لتطبيق مفاهيم DevOps: Docker, Kubernetes, Terraform, Ansible, Jenkins, ArgoCD.

## بنية المشروع

CloudDevOpsProject/
- app/
- docker/
- k8s/
- terraform/
- ansible/
- jenkins/
- argocd/

## تشغيل محلي
docker build -t ahmedbadawi/clouddevops:local -f docker/Dockerfile .
docker run -p 5000:5000 ahmedbadawi/clouddevops:local

## نشر على Kubernetes (minikube)
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml

## Terraform
terraform init
terraform plan
terraform apply

## Ansible
ansible-playbook -i inventories/aws_ec2.yml site.yml

## Jenkins
اضف credentials باسم ivolve-dockerhub-creds في Jenkins

## ArgoCD
استخدم argocd/argocd-application.yaml للـ sync التلقائي
